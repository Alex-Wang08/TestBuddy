package com.example.testbuddy.deeplink

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bluelinelabs.conductor.Controller
import com.example.testbuddy.R

class DeeplinkListController : Controller() {

    //region Variables

    //endregion



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup): View {
        val view = inflater.inflate(R.layout.controller_deeplink_list, container, false)

        return view
    }
}