package com.example.testbuddy.deeplink

interface DeeplinkListDelegate {

    fun placeHolder()
}