package com.example.testbuddy

interface MainDelegate {

    fun placeHolder()
}