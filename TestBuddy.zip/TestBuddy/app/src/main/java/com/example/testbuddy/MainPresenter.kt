package com.example.testbuddy

class MainPresenter(
    private val delegate: MainDelegate
) {



















}