package com.example.testbuddy.deeplink

class DeeplinkListPresenter {
}